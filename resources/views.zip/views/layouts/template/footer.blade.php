<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; <?php echo date('Y'); ?> <div class="bullet"></div>
    </div>
    <div class="footer-right">

    </div>
</footer>
