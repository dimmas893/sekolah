  <!-- General CSS Files -->
  <link rel="stylesheet" type="text/css" href="/assets/modules/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="/assets/modules/fontawesome/css/all.min.css">
  <link rel="stylesheet" type="text/css" href="/assets/css/style.css">
  <!-- CSS Libraries -->
  <link rel="stylesheet" type="text/css" href="/assets/modules/ionicons/css/ionicons.min.css">
  <link rel="stylesheet" type="text/css" href="/assets/css/components.css">
  {{-- <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css" rel="stylesheet" type="text/css" /> --}}
  <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
  <link href="https://cdn.datatables.net/responsive/2.4.0/css/responsive.bootstrap4.min.css" rel="stylesheet"
      type="text/css" />
  <link rel="stylesheet" type="text/css"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
      integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />
