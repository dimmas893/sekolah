@extends('layouts.template.template')
@section('content')
    <div class="main-content">

        <div class="modal fade" id="add_TU_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                        {{-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button> --}}
                    </div>
                    <form action="#" method="POST" id="add_TU_form" enctype="multipart/form-data">
                        @csrf
                        <div class="modal-body">
                            <div class="my-2">
                                <label for="name">Soal</label>
                                <textarea name="soal" class="form-control" placeholder="Masukan Soal" required></textarea>
                            </div>
                            <div class="my-2">
                                <label for="name">Jabawan A</label>
                                <textarea name="jawaban_a" class="form-control" placeholder="Masukan Jawaban A" required></textarea>
                            </div>
                            <div class="my-2">
                                <label for="name">Jabawan B</label>
                                <textarea name="jawaban_b" class="form-control" placeholder="Masukan Jawaban B" required></textarea>
                            </div>
                            <div class="my-2">
                                <label for="name">Jabawan C</label>
                                <textarea name="jawaban_c" class="form-control" placeholder="Masukan Jawaban C" required></textarea>
                            </div>
                            <div class="my-2">
                                <label for="name">Jabawan D</label>
                                <textarea name="jawaban_d" class="form-control" placeholder="Masukan Jawaban D" required></textarea>
                            </div>
                            <div class="my-2">
                                <label for="name">Kunci Jawaban</label>
                                <textarea name="kunci_jawaban" class="form-control" placeholder="Masukan Kunci Jawaban" required></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" id="add_TU_btn" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        {{-- add new employee modal end --}}

        {{-- edit employee modal start --}}
        <div class="modal fade" id="editTUModal" tabindex="-1" aria-labelledby="exampleModalLabel" data-backdrop="static"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit</h5>
                        {{-- <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button> --}}
                    </div>
                    <form action="#" method="POST" id="edit_TU_form" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="id" id="id">
                        <div class="modal-body">

                            <div class="modal-body">
                                <div class="my-2">
                                    <label for="name">Soal</label>
                                    <textarea name="soal" id="soal" class="form-control" placeholder="Masukan Soal" required></textarea>
                                </div>
                                <div class="my-2">
                                    <label for="name">Jabawan A</label>
                                    <textarea name="jawaban_a" id="jawaban_a" class="form-control" placeholder="Masukan Jawaban a" required></textarea>
                                </div>
                                <div class="my-2">
                                    <label for="name">Jabawan B</label>
                                    <textarea name="jawaban_b" id="jawaban_b" class="form-control" placeholder="Masukan Jawaban b" required></textarea>
                                </div>
                                <div class="my-2">
                                    <label for="name">Jabawan C</label>
                                    <textarea name="jawaban_c" id="jawaban_c" class="form-control" placeholder="Masukan Jawaban c" required></textarea>
                                </div>
                                <div class="my-2">
                                    <label for="name">Jabawan D</label>
                                    <textarea name="jawaban_d" id="jawaban_d" class="form-control" placeholder="Masukan Jawaban D" required></textarea>
                                </div>
                                <div class="my-2">
                                    <label for="name">Kunci Jawaban</label>
                                    <textarea name="kunci_jawaban" id="kunci_jawaban" class="form-control" placeholder="Masukan Kunci Jawaban" required></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" id="edit_TU_btn" class="btn btn-success">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        {{-- edit employee modal end --}}

        <section class="section">
            <div class="section-header">
                <h1>Halaman Data Soal</h1>
            </div>
            <div class="section-body">
                <div class="row my-5">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header bg-primary d-flex justify-content-between align-items-center">
                                <h3 class="text-light">Tabel Soal</h3>
                                <button class="btn btn-light" data-toggle="modal" data-target="#add_TU_modal"><i
                                        class="bi-plus-circle me-2"></i>Tambah Soal</button>
                            </div>
                            <div>
                                <div class="card-body" id="TU_all">
                                    <h1 class="text-secondary my-5 text-center">
                                        <div class="load-3">
                                            <div class="line"></div>
                                            <div class="line"></div>
                                            <div class="line"></div>
                                        </div>
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@section('js')
    <script>
        $(function() {
            // add new employee ajax request
            $("#add_TU_form").submit(function(e) {
                e.preventDefault();
                const fd = new FormData(this);
                $("#add_TU_btn").text('Adding...');
                $.ajax({
                    url: '{{ route('soal-store') }}',
                    method: 'post',
                    data: fd,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status == 200) {
                            Swal.fire(
                                'Added!',
                                'Added Successfully!',
                                'success'
                            )
                            TU_all();
                        }
                        $("#add_TU_btn").text('Save');
                        $("#add_TU_form")[0].reset();
                        $("#add_TU_modal").modal('hide');
                    }
                });
            });
            // edit employee ajax request
            $(document).on('click', '.editIcon', function(e) {
                e.preventDefault();
                let id = $(this).attr('id');
                $.ajax({
                    url: '{{ route('soal-edit') }}',
                    method: 'get',
                    data: {
                        id: id,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        $("#soal").val(response.soal);
                        $("#jawaban_a").val(response.jawaban_a);
                        $("#jawaban_b").val(response.jawaban_b);
                        $("#jawaban_c").val(response.jawaban_c);
                        $("#jawaban_d").val(response.jawaban_d);
                        $("#kunci_jawaban").val(response.kunci_jawaban);
                        $("#id").val(response.id);
                    }
                });
            });
            // update employee ajax request
            $("#edit_TU_form").submit(function(e) {
                e.preventDefault();
                const fd = new FormData(this);
                $("#edit_TU_btn").text('Updating...');
                $.ajax({
                    url: '{{ route('soal-update') }}',
                    method: 'post',
                    data: fd,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status == 200) {
                            Swal.fire(
                                'Updated!',
                                'Updated Successfully!',
                                'success'
                            )
                            TU_all();
                        }
                        $("#edit_TU_btn").text('Update');
                        $("#edit_TU_form")[0].reset();
                        $("#editTUModal").modal('hide');
                    }
                });
            });
            // delete employee ajax request
            $(document).on('click', '.deleteIcon', function(e) {
                e.preventDefault();
                let id = $(this).attr('id');
                let csrf = '{{ csrf_token() }}';
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: '{{ route('soal-delete') }}',
                            method: 'post',
                            data: {
                                id: id,
                                _token: csrf
                            },
                            success: function(response) {
                                console.log(response);
                                Swal.fire(
                                    'Deleted!',
                                    'Your file has been deleted.',
                                    'success'
                                )
                                TU_all();
                            }
                        });
                    }
                })
            });
            // fetch all employees ajax request
            TU_all();

            function TU_all() {
                $.ajax({
                    url: '{{ route('soal-all') }}',
                    method: 'get',
                    success: function(response) {
                        $("#TU_all").html(response);
                        $("table").DataTable({
                            destroy: true,
                            responsive: true
                        });
                    }
                });
            }
        });
    </script>
@endsection
