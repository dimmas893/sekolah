<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Perpustakaan_Pinjam extends Model
{
    use HasFactory;

	protected $table = 'perpustakaan_pinjam';
	protected $guarded = [];
}
